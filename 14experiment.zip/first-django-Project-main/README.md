# first-django-Project
My First Django project that is Course Management with full data connectivity with database-mysql . In this app we can purchase courses, users can Login-Logout . All the data of user is particular stored in mysql database table
